// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sweep Metropolis updates"); }
int main(){
  announce();
  return lionss_run_workload("isingMetropolis");
}
