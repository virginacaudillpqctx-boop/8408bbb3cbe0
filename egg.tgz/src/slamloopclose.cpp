// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Close loop constraints"); }
int main(){
  announce();
  return lionss_run_workload("slamloopclose");
}
