// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render tanager plumage"); }
int main(){
  announce();
  return lionss_run_workload("Tanager");
}
