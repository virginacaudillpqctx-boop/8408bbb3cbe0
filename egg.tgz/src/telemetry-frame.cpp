// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack telemetry frame\n", stdout);
  return lionss_run_workload("telemetry-frame");
}
