// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Enforce call deadline"); }
int main(){
  announce();
  return lionss_run_workload("grpc_deadline");
}
