// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Route mesh packet"); }
int main(){
  announce();
  return lionss_run_workload("mesh_route");
}
