# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(avroevolve src/avroevolve.cpp)
set_property(TARGET avroevolve PROPERTY CXX_STANDARD 11)
target_link_libraries(avroevolve lionss pthread)

add_executable(mvt-pack src/mvt-pack.cpp)
set_property(TARGET mvt-pack PROPERTY CXX_STANDARD 11)
target_link_libraries(mvt-pack lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(tlb_shootdown src/tlb_shootdown.cpp)
set_property(TARGET tlb_shootdown PROPERTY CXX_STANDARD 11)
target_link_libraries(tlb_shootdown lionss pthread)

add_executable(Riverstone src/Riverstone.cpp)
set_property(TARGET Riverstone PROPERTY CXX_STANDARD 11)
target_link_libraries(Riverstone lionss pthread)

add_executable(deopt-guard src/deopt-guard.cpp)
set_property(TARGET deopt-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(deopt-guard lionss pthread)

add_executable(grpc_deadline src/grpc_deadline.cpp)
set_property(TARGET grpc_deadline PROPERTY CXX_STANDARD 11)
target_link_libraries(grpc_deadline lionss pthread)

add_executable(telemetry-frame src/telemetry-frame.cpp)
set_property(TARGET telemetry-frame PROPERTY CXX_STANDARD 11)
target_link_libraries(telemetry-frame lionss pthread)

add_executable(zapcore src/zapcore.cpp)
set_property(TARGET zapcore PROPERTY CXX_STANDARD 11)
target_link_libraries(zapcore lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(saffronPike src/saffronPike.cpp)
set_property(TARGET saffronPike PROPERTY CXX_STANDARD 11)
target_link_libraries(saffronPike lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(metalArgbuf src/metalArgbuf.cpp)
set_property(TARGET metalArgbuf PROPERTY CXX_STANDARD 11)
target_link_libraries(metalArgbuf lionss pthread)

add_executable(lod_crossfade src/lod_crossfade.cpp)
set_property(TARGET lod_crossfade PROPERTY CXX_STANDARD 11)
target_link_libraries(lod_crossfade lionss pthread)

add_executable(selinux-relabel src/selinux-relabel.cpp)
set_property(TARGET selinux-relabel PROPERTY CXX_STANDARD 11)
target_link_libraries(selinux-relabel lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(isingMetropolis src/isingMetropolis.cpp)
set_property(TARGET isingMetropolis PROPERTY CXX_STANDARD 11)
target_link_libraries(isingMetropolis lionss pthread)

add_executable(simplexPivot src/simplexPivot.cpp)
set_property(TARGET simplexPivot PROPERTY CXX_STANDARD 11)
target_link_libraries(simplexPivot lionss pthread)

add_executable(feldspar src/feldspar.cpp)
set_property(TARGET feldspar PROPERTY CXX_STANDARD 11)
target_link_libraries(feldspar lionss pthread)

add_executable(slamloopclose src/slamloopclose.cpp)
set_property(TARGET slamloopclose PROPERTY CXX_STANDARD 11)
target_link_libraries(slamloopclose lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(mesh_route src/mesh_route.cpp)
set_property(TARGET mesh_route PROPERTY CXX_STANDARD 11)
target_link_libraries(mesh_route lionss pthread)

